Pense na memória do computador como um monte de caixas, onde você pede um espaço ao computador, e ele te dá um endereço onde você pode guardar um item.

![[Pasted image 20250327165433.png]]

Se você quer guardar vários itens existem duas formas simples de fazer isso: [[10 - Arrays |Arrays]] e [[11 - Listas|Listas]] 
