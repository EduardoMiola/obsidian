1.3 - O(log n)
1.4 - O(n)
1.5 - O(n)
1.6 - O(n) porque excluímos as constantes O(n/26)


[[00 - Velocidade de Algoritmos]]
[[03 - Big O Notation]]
[[05 - Complexidade log (n)]]
[[04 - Complexidade linear]]

[[02 - Exercícios (28)]]