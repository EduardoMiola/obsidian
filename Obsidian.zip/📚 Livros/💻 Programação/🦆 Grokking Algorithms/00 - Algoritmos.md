Algoritmos são conjuntos de operações usadas para realizar uma tarefa.

[[00 - Velocidade de Algoritmos|Velocidade]]
[[02 - Complexidade de algoritmos |Complexidade]]
[[01 - Busca binária |Busca binária]]
[[12 - Selection Sort|Selection Sort]]
[[03 - Big O Notation|Big O Notation]]

[[01 - Exercícios (17)]]
