A velocidade não é medida em segundos, mas em crescimento do número de operações, através da [[03 - Big O Notation|Notação Big O]].

Em vez disso, falamos sobre o quão rápido o tempo de operação de um [[00 - Algoritmos|Algoritmo]] aumenta quando o tamanho do input aumenta.


