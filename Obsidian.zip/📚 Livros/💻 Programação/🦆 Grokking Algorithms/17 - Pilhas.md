## 🔹O que são?

Pilhas ou Stacks são estruturas de dados que recebem sempre novos itens no seu topo e tem os elementos também retirados do seu topo, como uma pilha de pratos.
