A notação big O te diz o quão rápido um algoritmo é.

A big O leva em conta sempre o pior caso.


> [!NOTE] Importante 
> Além de levar em conta os piores casos, também é importante olhar para o caso médio.


[[04 - Complexidade linear]] O(n) 
[[05 - Complexidade log (n)]] O(log n)
[[06 - Complexidade n log n]] O(n * log n)
[[07 - Complexidade n^2]] O(n*n)
[[08 - Complexidade n!]] O(n!)