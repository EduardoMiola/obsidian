- Mede o tempo e o espaço necessários para um algoritmo rodar.

- [[03 - Big O Notation]]

